import React from 'react'

const FooterComponents = () => {
    return (
        <div>
            <footer className = "footer">
                 <span className="text-muted">All Rights Reserved 2023 @elaBADU.com</span>
            </footer>
        </div>
    )
}

export default FooterComponents